library(ggplot2)
library(reshape) # To convert dataframe to long format
library(MASS) # For the moment, stealing their parallel plot

library(cem)
data(LL)
detach(package:cem)

#####################
# CONTROL FUNCTIONS #
#####################

# These are the functions that users are supposed to call. 

# This gets the frontier
makeFrontier <- function(treatment, dataset, drop, mdist = NULL, QOI, metric, S){
    if(QOI == 'FSATT' & metric == 'Mahal' & S == 0){
        return(MahalFrontierFSATT(treatment="treated", dataset, drop, mdist))
    }
    if(QOI == 'SATT' & metric == 'Mahal' & S == 0){
        return(MahalFrontierSATT(treatment="treated", dataset, drop, mdist))
    }
    if(QOI == 'SATT' & metric == 'L1' & S == 1){
        return(L1FrontierSATT(treatment="treated", dataset, drop))
    }
    if(QOI == 'FSATT' & metric == 'L1' & S == 0){
        return(L1FrontierCEM(treatment="treated", dataset, drop))
    }
}

## A function to estimate causal effects
frontierEst <- function(frontierObject, dataset, myform=NULL, treatment=NULL, estCall=NULL, drop=NULL){

  ## Mahal
  if(frontierObject$metric=="Mahal" | frontierObject$metric=="Mahalj2k" | frontierObject$metric=="L1w"){
    # Causal Effects
    effectholder <- c()
    seholder <- c() 

    cat("Calculating estimates along the frontier\n")
    pb <- txtProgressBar(min=1,max=length(frontierObject$balance),initial = 1, style = 3)
    if(!is.null(estCall)){
      estCall <- gsub("WEIGHTS","frontierObject$weights[[i]][rownames(dataset)]",estCall, fixed=T)
    } else { 
    ## some warnings 
      if(is.null(treatment)){stop("\"treatment\" must be specified (as a string).")}
      if(is.null(myform)){stop("\"myform\" must be specified (as a formula).")}
    }
    for(i in 1:length(frontierObject$balance)){
      setTxtProgressBar(pb, i)
      ## how far through drops do we go?
#      dropseq <- (nrow(dataset)-frontierObject$samplesize[1]):(nrow(dataset)-frontierObject$samplesize[i])
      ## If there isn't a model specified, we just do linear regression with the formula
      if(is.null(estCall)){
        dataset$myw <- frontierObject$weights[[i]][rownames(dataset)]
#        m1 <- lm(myform, data=dataset[!(rownames(dataset) %in% frontierObject$drops[dropseq]),])
        m1 <- lm(myform, data=dataset, weights=myw)
        effectholder <- c(effectholder, summary(m1)$coeff[treatment,1])
        seholder <- c(seholder, summary(m1)$coeff[treatment,2])
      }
      ## if estCall is specified, then we just take whatever quantity of interest it is
      if(!is.null(estCall)){
        est <- eval(parse(text=estCall))
        effectholder <- c(effectholder, est[1])
        seholder <- c(seholder, est[2])
      }
    }
    close(pb)

    q <- data.frame(x = nrow(dataset)-frontierObject$samplesize)
    q$mean <- effectholder
    q$sd <- seholder
  }

  ## L1
  if(frontierObject$metric=="L1"){
    # Causal Effects
    effectholder <- c()
    seholder <- c() 

    ## replace the name DATASET with the subsetted data
    if(!is.null(estCall)){
      estCall <- gsub("DATASET","dataset[!(rownames(dataset)  %in% frontierObject$drops[1:i]),]",estCall, fixed=T)
    } else { 
    ## some warnings 
      if(is.null(treatment)){stop("\"treatment\" must be specified (as a string).")}
      if(is.null(myform)){stop("\"myform\" must be specified (as a formula).")}
    }

    cat("Calculating estimates along the frontier\n")
    pb <- txtProgressBar(min=1,max=length(frontierObject$balance),initial = 1, style = 3)

    for(i in 1:length(frontierObject$drops)){
      setTxtProgressBar(pb, i)
      if(is.null(estCall)){
        m1 <- lm(myform, data=dataset[!(rownames(dataset)  %in% frontierObject$drops[1:i]),], )
        effectholder <- c(effectholder, summary(m1)$coeff["treated",1])
        seholder <- c(seholder, summary(m1)$coeff["treated",2])
      }
      if(!is.null(estCall)){
        est <- eval(parse(text=estCall))
        effectholder <- c(effectholder, est[1])
        seholder <- c(seholder, est[2])
      }     
    }
    close(pb)

    q <- data.frame(x = seq(1, length(frontierObject$drops)))

    q$mean <- effectholder
    q$sd <- seholder

  }
  return(q)

  ## L1w
  if(frontierObject$metric=="L1w"){
    # Causal Effects
    effectholder <- c()
    seholder <- c() 

    ## replace the name DATASET with the subsetted data
    if(!is.null(estCall)){
      estCall <- gsub("DATASET","dataset[!(rownames(dataset)  %in% frontierObject$drops[1:i]),]",estCall, fixed=T)
    } else { 
    ## some warnings 
      if(is.null(treatment)){stop("\"treatment\" must be specified (as a string).")}
      if(is.null(myform)){stop("\"myform\" must be specified (as a formula).")}
    }

    cat("Calculating estimates along the frontier\n")
    pb <- txtProgressBar(min=1,max=length(frontierObject$balance),initial = 1, style = 3)

    for(i in 1:length(frontierObject$drops)){
      setTxtProgressBar(pb, i)
      if(is.null(estCall)){
        m1 <- lm(myform, data=dataset[!(rownames(dataset)  %in% frontierObject$drops[1:i]),], )
        effectholder <- c(effectholder, summary(m1)$coeff["treated",1])
        seholder <- c(seholder, summary(m1)$coeff["treated",2])
      }
      if(!is.null(estCall)){
        est <- eval(parse(text=estCall))
        effectholder <- c(effectholder, est[1])
        seholder <- c(seholder, est[2])
      }     
    }
    close(pb)

    q <- data.frame(x = seq(1, length(frontierObject$drops)))

    q$mean <- effectholder
    q$sd <- seholder
  }
  return(q)
}

generateDataset <- function(finalFrontierObject, dataset, number.dropped){
  ## If L1 frontier
  if(finalFrontierObject$metric=="L1"){
    keep <- !(nrow(dataset) %in% finalFrontierObject$drops[0:number.dropped])
    return(dataset[keep,])
  } 
  ## If Mahalanobis frontier
  if(finalFrontierObject$metric=="Mahal" | finalFrontierObject$metric=="Mahalj2k"){
    if(number.dropped > length(finalFrontierObject$drops)){stop(paste("number.dropped must be less than ",length(finalFrontierObject $drops),".",sep=""))}
    if(number.dropped %in% (nrow(dataset)-finalFrontierObject$samplesize)){
      dataset$w = finalFrontierObject$weights[[which((nrow(dataset)-finalFrontierObject$samplesize) == number.dropped)]]
      keep <- !(rownames(dataset) %in% finalFrontierObject$drops[0:number.dropped])
      return(dataset[keep,])
    } else {
      ## calculate the nearest two options
      min2 <- sort(abs((nrow(dataset)-finalFrontierObject$samplesize) - number.dropped))[1]
      suggestions <- (nrow(dataset)-finalFrontierObject$samplesize)[which(abs((nrow(dataset)-finalFrontierObject$samplesize) - number.dropped) %in%  min2)]
      stop(paste("There is no dataset on the frontier with ",number.dropped," dropped observations.\n  The closest options for number.dropped  are",paste(paste(suggestions[1:(length(suggestions)-1)],collapse=", ")," or ",tail(suggestions,1),".",sep="")))
    }
  }
}

######################
# PLOTTING FUNCTIONS #
######################

# Make some pretty pictures
# function standardizes everything to 0 - 1
range01 <- function(x){
  if(min(x) == max(x)){
    x <- rep(0, length(x))
    return(x)
  }
  (x-min(x))/(max(x)-min(x))
}

# Function for combining plots made with ggplot
multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  require(grid)

  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)

  numPlots = length(plots)

  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                    ncol = cols, nrow = ceiling(numPlots/cols))
  }

 if (numPlots==1) {
    print(plots[[1]])

  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))

    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))

      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}


frontierPlotL1 <- function(frontierObject, dataset, frontierEstObject=NULL, zoom = NULL, drop=NULL){

  starting.index <- 1
  ending.index <- length(frontierObject$drops)
  if(!is.null(zoom)){
    starting.index <- zoom[1]
    ending.index <- tail(zoom, 1)
  }
  
  # Frontier
  df <- data.frame(x = seq(starting.index, ending.index), y = frontierObject$balance[starting.index:ending.index])

  p1 <- ggplot(df, aes(x=x, y=y)) +
      geom_line() +
      xlab("Number of Observations Dropped") +
      ylab("Imbalance") +
      ggtitle("Imbalance Frontier")

  # Causal Effects
  if(!is.null(frontierEstObject)){
    q <- frontierEstObject[starting.index:ending.index,]
    eb <- aes(ymax = mean + sd, ymin = mean - sd)

    p2 <- ggplot(data = q, aes(x = x, y = mean)) + 
      geom_line(size = 1) + geom_point() +
      geom_ribbon(eb, alpha = 0.5) +
      xlab("Number of Observations Dropped") +
      ylab("Effect Size and SEs")
  } else {
    p2 <- NULL
  }

  # Overall Means
  drop <- c('treated', 're78')
  covs <- colnames(dataset)[!(colnames(dataset) %in% drop)]

  for(col in covs){
      dataset[,colnames(dataset) == col] <- range01(dataset[,colnames(dataset) == col])
    }

  covs.mat <- matrix(nrow = 0, ncol = length(covs), byrow = FALSE)
  colnames(covs.mat) <- covs

  for(i in 1:length(frontierObject$drops)){
    iter.dat <- dataset[!(rownames(dataset) %in% frontierObject$drops[1:i]),]
    new.row <- c()
    for(c in colnames(covs.mat)){
      new.row <- c(new.row, mean(iter.dat[,c]))
      }
    covs.mat <- rbind(covs.mat, new.row)
  }
  rownames(covs.mat) <- seq(nrow(covs.mat))

  data.long <- melt(covs.mat[starting.index:ending.index,])

  p3 <- ggplot(data=data.long,
               aes(x=X1, y=value, colour=X2)) +
    geom_line() +
    xlab("Number of Observations Dropped") +
    ylab("Standardized Mean Value") +
    opts(legend.position="bottom") +
    theme(legend.title=element_blank())

  # Join
  if(!is.null(p2)){
    p.final <- multiplot(p1, p2, p3, cols=1)
  } else {
    p.final <- multiplot(p1, p3, cols=1)
  }

  return(list(p.final,covs.mat))
}


frontierPlotMahal <- function(frontierObject, dataset, frontierEstObject=NULL, zoom = NULL, drop=NULL){

  starting.index <- 1
  #ending.index <- length(frontierObject$drops)
  ending.index <- length(frontierObject$balance)
  if(!is.null(zoom)){
    ## I made a warning for zoom
    if(zoom[1]<0 | tail(zoom, 1) > length(frontierObject$drops)){stop(paste("zoom must be between 0 and ",length(frontierObject$drops)," for this data  set.",sep=""))}
    ## get the index corresponding with the requested number of obs to remove for the start of the zoom
    starting.index <- which(abs((frontierObject$samplesize[1] - frontierObject$samplesize)-zoom[1]) == min(abs((frontierObject$samplesize[1] -  frontierObject$samplesize)-zoom[1])))[1]
    ## get the index corresponding with the requested number of obs to remove for the end of the zoom
    ending.index <- tail( which(abs((frontierObject$samplesize[1] - frontierObject$samplesize)-tail(zoom, 1)) == min(abs((frontierObject$samplesize[1]  - frontierObject$samplesize)-tail(zoom, 1)))), 1)
  }
  
  # Frontier
  #df <- data.frame(x = seq(starting.index, ending.index), y = frontierObject$balance[starting.index:ending.index])
  df <- data.frame(x = nrow(dataset)-frontierObject$samplesize[starting.index:ending.index], 
                   y = frontierObject$balance[starting.index:ending.index])
  
  p1 <- ggplot(df, aes(x=x, y=y)) +
      geom_line() + geom_point() +
      xlab("Number of Observations Dropped") +
      ylab("Imbalance") +
      ggtitle("Imbalance Frontier")


  # Causal Effects
  if(!is.null(frontierEstObject)){
    q <- frontierEstObject[starting.index:ending.index,]
    eb <- aes(ymax = mean + sd, ymin = mean - sd)

    p2 <- ggplot(data = q, aes(x = x, y = mean)) + 
      geom_line(size = 1) + geom_point() +
      geom_ribbon(eb, alpha = 0.5) +
      xlab("Number of Observations Dropped") +
      ylab("Effect Size and SEs")
  } else {
    p2 <- NULL
  }


  # Overall Means
  covs <- colnames(dataset)[!(colnames(dataset) %in% drop)]

  for(col in covs){
      dataset[,colnames(dataset) == col] <- range01(dataset[,colnames(dataset) == col])
    }

  covs.mat <- matrix(nrow = 0, ncol = length(covs), byrow = FALSE)
  colnames(covs.mat) <- covs

  for(i in 1:length(frontierObject$balance)){
    ## how far through drops do we go?
    dropseq <- (nrow(dataset)-frontierObject$samplesize[1]):(nrow(dataset)-frontierObject$samplesize[i])
    iter.dat <- dataset[!(rownames(dataset) %in% frontierObject$drops[dropseq]),]
    new.row <- c()
    for(c in colnames(covs.mat)){
      new.row <- c(new.row, mean(iter.dat[,c]))
      }
    covs.mat <- rbind(covs.mat, new.row)
  }
  #rownames(covs.mat) <- seq(nrow(covs.mat))
  rownames(covs.mat) <- nrow(dataset) - frontierObject$samplesize

  data.long <- melt(covs.mat[starting.index:ending.index,])

  p3 <- ggplot(data=data.long,
               aes(x=X1, y=value, colour=X2)) +
    geom_line() + 
    xlab("Number of Observations Dropped") +
    ylab("Standardized Mean Value") +
    opts(legend.position="bottom") +
    theme(legend.title=element_blank())

  # Join
  if(!is.null(p2)){
    p.final <- multiplot(p1, p2, p3, cols=1)
  } else {
    p.final <- multiplot(p1, p3, cols=1)
  }

  p.final
  #return(list(p.final,covs.mat))
  return(invisible(list(covs.mat=covs.mat)))
}


# Function for user
frontierPlot <- function(frontierObject, dataset, frontierEstObject=NULL, zoom = NULL, drop=NULL){
  ## Plot L1 frontier
  if(frontierObject$metric=="L1"){
    frontierPlotL1(frontierObject=frontierObject, dataset=dataset, frontierEstObject=frontierEstObject, zoom=zoom, drop=drop)
  }
  ## Plot Mahal frontier
  if(frontierObject$metric=="Mahal" | frontierObject$metric=="Mahalj2k" | frontierObject$metric=="L1w"){
    frontierPlotMahal(frontierObject=frontierObject, dataset=dataset, frontierEstObject=frontierEstObject, zoom=zoom, drop=drop)
  }
}
  
######################
# FRONTIER FUNCTIONS #
######################

makeFrontier <- function(treatment, dataset, drop, mdist = NULL, QOI, metric, S){
    if(QOI == 'FSATT' & metric == 'Mahal' & S == 0){
        return(MahalFrontierFSATT(treatment="treated", dataset, drop, mdist))
    }
    if(QOI == 'SATT' & metric == 'Mahal' & S == 0){
        return(MahalFrontierSATT(treatment="treated", dataset, drop, mdist))
    }
    if(QOI == 'FSATT' & metric == 'L1' & S == 1){
        return(L1FrontierFSATT(treatment="treated", dataset, drop))
    }
    if(QOI == 'SATT' & metric == 'L1' & S == 1){
        return(L1FrontierSATT(treatment="treated", dataset, drop))
    }
    if(QOI == 'FSATT' & metric == 'L1' & S == 0){
        return(L1FrontierCEM(treatment="treated", dataset, drop))
    }
}

myMH <- function(Tnms, Cnms, inv.cov, dataset) {
 stopifnot(!is.null(dimnames(inv.cov)[[1]]), dim(inv.cov)[1] >
 1, all.equal(dimnames(inv.cov)[[1]], dimnames(inv.cov)[[2]]),
 all(dimnames(inv.cov)[[1]] %in% names(dataset)))
 covars <- dimnames(inv.cov)[[1]]
 xdiffs <- as.matrix(dataset[Tnms, covars])
 xdiffs <- xdiffs - as.matrix(dataset[Cnms, covars])
 rowSums((xdiffs %*% inv.cov) * xdiffs)
}

checkMatrix <- function(mdist, dataset, treatment){
    if(!is.matrix(mdist)){stop("the mdist provided is not a matrix")}
    ## are all the rownames of mdist treated units in the data?
    if(sum(rownames(mdist) %in% rownames(dataset[dataset[[treatment]]==1,])) != nrow(mdist)){stop("the rownames of mdist do not match the names of the treated units in the data.")}
    ## are all the treated units in the data listed as rows in mdist?
    if(sum(rownames(dataset[dataset[[treatment]]==1,]) %in% rownames(mdist)) != nrow(mdist)){stop("the rownames of mdist do not match the names of the treated units in the data.")}
    ## are all the colnames of mdist control units in the data?
    if(sum(colnames(mdist) %in% rownames(dataset[dataset[[treatment]]==0,])) != ncol(mdist)){stop("the colnames of mdist do not match the names of the control units in the data.")}  
    ## are all the control units in the data listed as columns in mdist?
    if(sum(rownames(dataset[dataset[[treatment]]==0,]) %in% colnames(mdist)) != ncol(mdist)){stop("the colnames of mdist do not match the names of the control units in the data.")}
}

calculateMdist <- function(dataset, treatment, matchVars){
    ## calculate the inverse covariance matrix
    icv <- solve(cov(dataset[, matchVars]))
    ## get the names of the treated
    trtnms <- row.names(dataset)[as.logical(dataset[[treatment]])]
    ## and the names of the control units
    ctlnms <- row.names(dataset)[!as.logical(dataset[[treatment]])]
    ## calculate the mahalanobis distances if not specified
    mdist <- outer(trtnms, ctlnms, FUN = myMH, inv.cov = icv, data = dataset)                                                                                  
    dimnames(mdist) <- list(trtnms, ctlnms)
    return(mdist)
}

frontierLoop <- function(dataset, treatment, distvec, minlist, mdist, strataList){
    ## Series of holders to store info about the frontier
    outholder <- c();dropped <- c();imbalance <- c(); matchedSampleSize <- c();wList <- list()
    
    ## Start a loop over the number of unique minimum distances
    for(i in 1:length(distvec)){
        ## We keep all units that have minimum distances <= this value
        currentThreshold <- distvec[i]
        ## This is the subset of minimum units that remain
        remainingMinimums <- minlist[minlist <= currentThreshold]
        ## we need the matched sample size
        matchedSampleSize <- c(matchedSampleSize, length(remainingMinimums))
        
        this.drop <- rownames(dataset)[!(rownames(dataset) %in% c(names(remainingMinimums), dropped))]
        dropped <- c(dropped, this.drop)
        
        ## calculate the Avg of all the minimum Mahalanobis discrepancies
        imbalance <- c(imbalance, mean(remainingMinimums))
        
        ## NEW -- calcalate a weights vector for this drop
        m_T <- table(dataset[[treatment]])[["1"]]
        m_C <- table(dataset[[treatment]])[["0"]]
        
        W <- rep(NA, nrow(dataset))
        names(W) <- rownames(dataset)
        ## fill in 1s for treated units that are still in
        W[(names(W) %in% rownames(mdist)) & (names(W) %in% names(remainingMinimums))] <- 1
        ## fill in 0s for all units that re out
        W[!(names(W) %in% names(remainingMinimums))] <- 0
        ## fill in weights for the rest
        cLeft <- W[(names(W) %in% colnames(mdist)) & (names(W) %in% names(remainingMinimums))]
        for(j in 1:length(cLeft)){
            sTab <- table(dataset[ names(strataList)[ strataList == strataList[names(cLeft[j])] ], ][[treatment]])
            m_T_s <- sTab["1"]
            m_C_s <- sTab["0"]
            W[names(cLeft[j])] <- (m_C/m_T)*(m_T_s/m_C_s)
        }
        wList[[i]] <- W 
    }
    return(list(balance = imbalance, drops = dropped, samplesize = matchedSampleSize, metric="Mahal", weights=wList))
}

makeStrata <- function(mdist, dataset, minlist){
    ##NEW -- try to calculate the parts for cemweights
    ## identify all obs that are mutually minimum to each other and call those strata
    ss <- list()
    for(i in 1:nrow(mdist)){
        ss[[length(ss)+1]] <- c(rownames(mdist)[i], names(which(mdist[i,] == minlist[rownames(mdist)[i]])))
    }
    for(i in 1:ncol(mdist)){
        ss[[length(ss)+1]] <- c(colnames(mdist)[i], names(which(mdist[,i] == minlist[colnames(mdist)[i]])))
    }
    ## Then combine all of them so that
    names(ss) <- as.character(1:length(ss))
    ss.names <- names(ss)
    for(i in 2:length(ss.names)){
        tmp <- ss[[ss.names[i]]]
        whichshare <- lapply(lapply(ss[1:(i-1)], function(x){tmp %in% x}), sum)
        ## if there is only one prior strata to combine with...
        if(sum(unlist(whichshare)) == 1){
            ss[[names(whichshare)[whichshare >0]]] <- unique(c(ss[[names(whichshare)[whichshare >0]]], tmp))
            ss[[ss.names[i]]] <- ""
        }
        ## if there is MORE THAN one prior strata to combine with...
        if(sum(unlist(whichshare)) > 1){
            ss[[ names(whichshare)[whichshare >0][1] ]] <- unique(c(unlist(ss[ names(whichshare)[whichshare >0] ]), tmp))
            ss[[ss.names[i]]] <- ""
            for(j in 2:sum(unlist(whichshare))){
                ss[[ names(whichshare)[whichshare >0][j] ]] <- ""
            }
        }
    }
    ## remove the empty holders
    ss <- ss[lapply(ss,function(x){sum(x=="")})==0]
    if( length(unlist(ss))!=nrow(dataset)){stop("The internal calculation of strata weights has messed up.")}
    ## then make an observation list with strata
    strataList <- rep(NA, nrow(dataset))
    names(strataList) <- rownames(dataset)
    for(i in 1:length(strataList)){
        strataList[i] <- names(ss)[unlist(lapply(ss, function(x){rownames(dataset)[i] %in% x}))]
    }
    return(strataList)
}

MahalFrontierFSATT <- function(treatment, dataset, drop, mdist = NULL){
## the vector of matching covariates
  matchVars <-  colnames(dataset)[!(colnames(dataset) %in% drop)]

  # Get distance matrix
  if(is.null(mdist)){mdist <- calculateMdist(dataset, treatment, matchVars)}

  # Check distance matrix
  checkMatrix(mdist, dataset, treatment)

  ## calculate the length to the closest unit in the opposite treatment condition
  ## for each unit.
  minlist <- c(apply(mdist,1,min), apply(mdist,2,min))
   
  strataList <- makeStrata(mdist, dataset, minlist)
  
  ## make a vector of all the unique minimum distances
  ## (this is the number of calculations we have to make)
  distvec <- rev(sort(unique(minlist)))

  return(frontierLoop(dataset, treatment, distvec, minlist, mdist, strataList))
}

MahalFrontierSATT <- function(treatment, dataset, drop, mdist){
    print("We presently can't calculate a Mahalanobis SATT frontier.")
}

######################
# END OF STUFF FOR MAHALANOBIS - BEGINNING OF L1
######################

getStrata <- function(treatment, dataset, drop, breaks=NULL){

  # Remove dropped observations
  dropped <- match(drop, colnames(dataset))
  if(length(dropped) > 0){
    dataset <- dataset[-dropped]
  }

  ## stuff borrowed from cem.main to add user defined breaks
  vnames <- colnames(dataset)
  nv <- dim(dataset)[2]
  mycut <- vector(nv, mode="list")
  names(mycut) <- vnames
  for (i in 1:nv) {	
    tmp <- reduceVar(dataset[[i]], breaks[[vnames[i]]])
    dataset[[i]] <- tmp$x
    mycut[[vnames[i]]] <- tmp$breaks
  }

  # Calculate strata
  strata <- stratify(dataset)
  return(list(strata=strata, mycut=mycut))
}

## the original reduce.var from cem
reduceVar <- function(x, breaks=NULL){
	if(is.numeric(x) | is.integer(x)){
	 if(is.null(breaks)){
	  breaks <- "sturges"
	  }
	 if(is.character(breaks)){
       breaks <- match.arg(tolower(breaks), c("sturges", 
                "fd", "scott", "ss"))
            breaks <- switch(breaks, sturges = nclass.Sturges(x), 
                 fd = nclass.FD(x), 
				 scott = nclass.scott(x), 
				 ss = nclass.ss(x),
                stop("unknown 'breaks' algorithm"))
        }
	 if(length(breaks) > 0){
		if(length(breaks)==1){
			rg <- range(x, na.rm=TRUE)
			breaks <- seq(rg[1],rg[2], length = breaks)
		}
		breaks <- unique(breaks)
		if(length(breaks)>1)
	     x <- cut(x, breaks=breaks, include.lowest = TRUE, labels = FALSE)
		else 	
		 x <- as.numeric(x) 
	 }
	} else {
	  x <- as.numeric(x) 
	}
	return(list(x=x, breaks=breaks)) 
}



# Takes a dataframe and returns a vector of length nrow(data), where
# element i is strata for observation i. 
stratify <- function (dataset){
  xx <- apply(dataset, 1, function(x) paste(x, collapse = "\r"))
  tab <- table(xx)
  st <- names(tab)
  strata <- match(xx,st)
  return(strata)
}

L1 <- function(strataholder){
  L1 <- 0
  num.treated <- 0
  num.control <- 0
  for(strat in strataholder){
    num.treated <- num.treated + sum((names(strat) == 1))
    num.control <- num.control + sum((names(strat) == 0))
  }
  for(strat in strataholder){
      strat.imb <- (sum(names(strat) == 1))/num.treated - (sum(names(strat) == 0))/num.control
      L1 <- L1 + abs(strat.imb)
  }
  return(L1 * .5)
}


L1FrontierCEM <- function(treatment, dataset, drop, breaks=NULL){
  require(cem)

  gs <- getStrata(treatment, dataset, drop, breaks=breaks)
  strata <- gs$strata
  mycut <- gs$mycut
  names(strata) <- dataset[,which(colnames(dataset) == treatment)]
  unique.strata <- unique(strata)
  strataholder <- list()
  for(i in 1:length(unique.strata)){
    strataholder[[i]] <- which(strata==unique.strata[i])
  }
  drops <- c()
  L1s <- c()
  samplesize <- c()
  wList <- list()

  ## calculate the L1 of the whole dataset
  imb <- imbalance(group=dataset[[treatment]], data=dataset, drop=drop, breaks = breaks)
  ## save the breaks that were randomly generated by the imbalance function
  if(is.null(breaks)){breaks <- imb$L1$breaks}
  L1s <- c(L1s, imb$L1$L1)
  samplesize <- c(samplesize, nrow(dataset))
  W <- rep(1,nrow(dataset))
  names(W) <- rownames(dataset)
  wList[[1]] <- W
  ## use cem to identify the singletons
  cem1 <- cem(treatment=treatment,data=dataset,cutpoints=breaks,L1.breaks=breaks,eval.imbalance=T, drop=drop)
  L1s <- c(L1s, cem1$imbalance$L1$L1)
  samplesize <- c(samplesize, sum(cem1$tab["Matched",]))
  W <- cem1$w
  names(W) <- rownames(dataset)
  wList[[2]] <- W
  
  #return(list(balance = L1s, drops = unname(drops), samplesize=samplesize, metric="L1-2", breaks=breaks))
  return(list(balance = L1s, samplesize=samplesize, metric="L1w", breaks=mycut, weights=wList))
}

L1FrontierSATT <- function(treatment, dataset, drop, breaks=NULL){
    gs <- getStrata(treatment, dataset, drop, breaks=breaks)
    strata <- gs$strata
    mycut <- gs$mycut
    names(strata) <- dataset[,which(colnames(dataset) == treatment)]
    unique.strata <- unique(strata)
    strataholder <- list()
    for(i in 1:length(unique.strata)){
        strataholder[[i]] <- which(strata==unique.strata[i])
    }
    drops <- c()
    L1s <- c()
    samplesize <- c()
    
    # Remove obs from imbalanced strata
    while(1){
    # get differences
        difference.vec <- c()
        
        for(s in 1:length(strataholder)){
            d <- sum(names(strataholder[[s]]) == '1') - sum(names(strataholder[[s]]) == '0')
            difference.vec <- c(difference.vec, d)
        }

        difference.vec[difference.vec > 0] <- 0
        if(max(abs(difference.vec)) == 0){break}
        
        drop <- which(abs(difference.vec) == max(abs(difference.vec)))[1]
        drop.obs <- which(names(strataholder[[drop]]) == 0)[1]
        dropped <- strataholder[[drop]][drop.obs]
        drops <- c(drops, rownames(dataset)[dropped])
        samplesize <- c(samplesize, nrow(dataset)-length(drops))
        strataholder[[drop]] <- strataholder[[drop]][-drop.obs]
        
        L1s <- c(L1s, L1(strataholder))
        print(L1(strataholder))
    }
    return(list(balance = L1s, drops = unname(drops), samplesize=samplesize, metric="L1", breaks=mycut))
}

# THIS CODE IS FOR L1 SATT AND HAS A BUG!!!

## L1FromVecs <- function(treated.vec, control.vec){
##     .5 * abs(treated.vec/sum(treated.vec) - control.vec/sum(control.vec))
## }

## L1FrontierFSATT <- function(treatment, dataset, drop, breaks=NULL){
##   gs <- getStrata(treatment, dataset, drop, breaks=breaks)
##   strata <- gs$strata
##   mycut <- gs$mycut
##   names(strata) <- dataset[,which(colnames(dataset) == treatment)]
##   unique.strata <- unique(strata)
##   strataholder <- list()
##   for(i in 1:length(unique.strata)){
##     strataholder[[i]] <- which(strata==unique.strata[i])
##   }
##   drops <- c()
##   samplesize <- c()

##   treated.vec <- c()
##   control.vec <- c()
##   for(strat in strataholder){
##       treated.vec <- c(treated.vec, sum((names(strat) == 1)))
##       control.vec <- c(control.vec, sum((names(strat) == 0)))
##   }
##   FSATT.frontier <- getFrontier(treated.vec, control.vec, .05)
##   return(FSATT.frontier)
## }

## # This function just  
## extendVectors <- function(vector){
##   new.vector <- c()
##   for(i in 1:length(vector)){
##     new.vector <- c(new.vector, rep(i, vector[i]))
##   }
##   return(new.vector)
## }
    
## # This function basically calculates one point on the L1 frontier
## dropN <- function(treatment.vec, control.vec, number.to.drop){
##   num.treated <- sum(treatment.vec)
##   num.control <- sum(control.vec)

##   # treatment.denoms and control.denoms are the vectors whose ith elements sum to number.to.drop
##   treatment.denoms <- seq(num.treated, num.treated - number.to.drop) 
##   control.denoms <- seq(num.control - number.to.drop, num.control) 

##   # This is our holder for the best L1 in this iteration. Starting at 1.1 because it's nonsensical and impossible to lose to 1.
##   best.L1 <- 1.1
  
##   for(i in 1:(number.to.drop + 1)){    # For each possible denominator pairing
##     relative.diff <- treatment.vec/treatment.denoms[i] - control.vec/control.denoms[i] #vector of diffs normalized by eventual denominators

##     # Number of treated and control dropped for this iteration
##     num.treated.drop <- num.treated - treatment.denoms[i]          
##     num.control.drop <- num.control - control.denoms[i]

##     # This calculates what L1 will be for these denominator values, in the best case. If bad, next. 
##     L1 <- (sum(abs(relative.diff)) - num.treated.drop/treatment.denoms[i] - num.control.drop/control.denoms[i]) * .5

##     if(L1 > best.L1){next}

##     # These vectors are the number of T and C we can remove and improve L1. They all improve L1 equally. 
##     t.factored <- floor((relative.diff + .01) / (1/treatment.denoms[i]))
##     t.factored[t.factored < 0] <- 0
##     c.factored <- ceiling((relative.diff - .01)/ (1/control.denoms[i]))
##     c.factored[c.factored > 0] <- 0
##     c.factored <- abs(c.factored)

##     # If we can't remove enough observations w/out making L1 worse, next. 
##     if(num.treated.drop > sum(t.factored)){next}
##     if(num.control.drop > sum(c.factored)){next}

##     # Randomly sample some strata to drop from
##     treatment.drop <- sample(extendVectors(t.factored), num.treated.drop)
##     control.drop <- sample(extendVectors(c.factored), num.control.drop)

##     best.L1 <- L1
##   }  
##   return(list(treatment.drop = treatment.drop, control.drop = control.drop, L1 = best.L1))
## }

## # This function gets the rest of the frontier. Epsilon is some small arbitrary value of L1 at which we break from the loop
## getFrontier <- function(treatment.vec, control.vec, epsilon){
##   current.L1 <- abs(treatment.vec/sum(treatment.vec) - control.vec/sum(control.vec)) * .5
##   number.to.drop <- 1
##   frontierObject <- list() # Holder for results
##   while(1){
##     frontierObject[[number.to.drop]] <- dropN(treatment.vec, control.vec, number.to.drop)
##     if(frontierObject[[number.to.drop]][['L1']] < epsilon){break}
##     number.to.drop <- number.to.drop + 1
##   }
##   return(frontierObject)
## }
